package com.thoughtworks.acceptance.someobjects;

import java.util.List;

/**
 *
 * 
 * @author <a href="mailto:jason@maven.org">Jason van Zyl</a>
 *
 * @version $Id: HandlerManager.java 1049 2006-11-10 21:28:33Z joehni $
 */
public class HandlerManager
{
    List handlers;

    public List getHandlers()
    {
        return handlers;
    }
}
