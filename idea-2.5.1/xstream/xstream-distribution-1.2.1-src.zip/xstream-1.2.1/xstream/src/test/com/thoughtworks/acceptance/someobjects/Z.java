package com.thoughtworks.acceptance.someobjects;

import com.thoughtworks.acceptance.StandardObject;

public class Z extends StandardObject {
	public String field;
	
	public Z(String z){
		this.field = z;
	}
	
}
