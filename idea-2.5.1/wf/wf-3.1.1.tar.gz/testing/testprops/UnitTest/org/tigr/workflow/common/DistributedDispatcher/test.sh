#!/bin/sh


echo "Running test.sh"
echo "Host Name:"  `hostname`
uname -a
id
sleep 10

echo "done seeya later"
echo $?

